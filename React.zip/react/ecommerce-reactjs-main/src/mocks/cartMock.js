export const cartMock = [
  {
    id: 'asus-vivobook-pro-14-oled-core-i5-11300h-8gb-256gb',
    name: 'Asus Vivobook Pro \n    14 Oled \n    Core i5 11300H \n    8GB / 256GB',
    price: 284890,
    quantity: 1
  },
  {
    id: 'new-kindle-paperwhite-6-8-16gb-resistente-al-agua-11va-gen-negro',
    name: 'New Kindle Paperwhite 6.8″ 16GB \n    Resistente al Agua \n    11va Gen \n    Negro',
    price: 81890,
    quantity: 1
  },
  {
    id: 'asus-zenbook-flip-2en1-ryzen-7-5700u-8gb-256gb-geforce-mx450',
    name: 'Asus ZenBook Flip 2en1 \n    15.6″ \n    Ryzen 7 5700U \n    8GB / 256GB \n    GeForce MX450',
    price: 389890,
    quantity: 2
  }
]
