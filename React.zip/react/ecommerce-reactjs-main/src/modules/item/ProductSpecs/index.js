export * from './ProductSpecs'
export { default } from './ProductSpecs'
