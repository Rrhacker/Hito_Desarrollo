export * from './ProductTags'
export { default } from './ProductTags'
