export * from './TextWithLineBreaks'
export { default } from './TextWithLineBreaks'
