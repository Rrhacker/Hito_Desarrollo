export * from './QuickAddToCart'
export { default } from './QuickAddToCart'
